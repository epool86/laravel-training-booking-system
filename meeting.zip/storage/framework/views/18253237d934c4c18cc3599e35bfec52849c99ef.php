<div>
<hr>
&copy; Copyright Booking System
</div><?php /**PATH C:\laragon\www\meeting\resources\views/includes/footer.blade.php ENDPATH**/ ?>