

<?php $__env->startSection('page_title'); ?>
Manage Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">List of My Bookings</div>

    <div class="card-body">

        <table>
            <tr>
                <td><a href="<?php echo e(route('app.booking.create')); ?>" class="btn btn-primary">Create New Booking</a></td>
                <td><input type="text" class="form-control" name="search" id="search" value="<?php echo e($search); ?>" placeholder="staff name"></td>
                <td><input type="text" class="form-control" name="search2" id="search2" value="<?php echo e($search2); ?>" placeholder="room name"></td>
                <td><button type="button" class="btn btn-primary" name="" onclick="search()">Search</button></td>
            </tr>
        </table>

        
        
        <table class="table">
            <tr>
                <th>No</th>
                <th>Date</th>
                <th>Staff Name</th>
                <th>Room Name</th>
                <th>Time From</th>
                <th>Time To</th>
                <th>Pax</th>
                <th>Remark</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php ($i = 0); ?>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($booking->date); ?></td>
                <td><?php echo e($booking->user->name); ?></td>
                <td><?php echo e($booking->room->name); ?></td>
                <td><?php echo e($booking->time_from); ?></td>
                <td><?php echo e($booking->time_to); ?></td>
                <td><?php echo e($booking->pax); ?></td>
                <td><?php echo e($booking->remark); ?></td>
                <td>
                    <?php if($booking->status == 0): ?>
                        <span class="badge bg-warning">Pending</span>
                    <?php elseif($booking->status == 1): ?>
                        <span class="badge bg-success">Success</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Rejected</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('app.admin.booking.update', $booking->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="PUT">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                        <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
    </div>
</div>

<script type="text/javascript">
    
    function search(){

        var search = document.getElementById('search').value;
        var search2 = document.getElementById('search2').value;
        self.location = '<?php echo e(route('app.admin.booking.index')); ?>?search='+search+'&search2='+search2;

    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/admin/booking_index.blade.php ENDPATH**/ ?>