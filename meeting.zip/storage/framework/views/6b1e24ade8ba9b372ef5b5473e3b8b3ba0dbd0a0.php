<a href="<?php echo e(route('app.dashboard')); ?>" class="btn btn-primary w-100 mb-1">Dashboard</a>
<a href="<?php echo e(route('app.booking.index')); ?>" class="btn btn-primary w-100 mb-1">My Booking</a>
<a href="" class="btn btn-primary w-100 mb-1">Update Profile</a>
<button class="btn btn-danger w-100 mb-1" 
onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</button><?php /**PATH C:\laragon\www\meeting\resources\views/includes/menu_user.blade.php ENDPATH**/ ?>