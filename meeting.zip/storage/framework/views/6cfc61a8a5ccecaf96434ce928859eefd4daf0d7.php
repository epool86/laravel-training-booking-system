

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">List of Users</div>

    <div class="card-body">

        <table>
            <tr>
                <td><a href="<?php echo e(route('app.admin.user.create')); ?>" class="btn btn-primary">Create User</a></td>
                <td><input type="text" class="form-control" name="search" id="search" value="<?php echo e($search); ?>"></td>
                <td><button type="button" class="btn btn-primary" name="" onclick="search()">Search</button></td>
            </tr>
        </table>
        
        <table class="table">
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Staff ID</th>
                <th>Department</th>
                <th>Role</th>
                <th>Action</th>
            </tr>

            <?php ($i = 0); ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->staff_id); ?></td>
                <td><?php echo e($user->department); ?></td>
                <td>
                    <?php if($user->role == 'user'): ?>
                        <span class="badge bg-success">User</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Admnin</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('app.admin.user.destroy', $user->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                    <a href="<?php echo e(route('app.admin.user.edit', $user->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <?php echo $users->appends($_GET)->render(); ?>

        
    </div>
</div>

<script type="text/javascript">
    
    function search(){

        var search = document.getElementById('search').value;
        self.location = '<?php echo e(route('app.admin.user.index')); ?>?search='+search;

    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/admin/user_index.blade.php ENDPATH**/ ?>