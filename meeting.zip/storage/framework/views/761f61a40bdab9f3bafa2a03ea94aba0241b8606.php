<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Page</title>
</head>
<body>
	<h1>About Page</h1>
</body>
</html><?php /**PATH C:\laragon\www\meeting\resources\views/about.blade.php ENDPATH**/ ?>