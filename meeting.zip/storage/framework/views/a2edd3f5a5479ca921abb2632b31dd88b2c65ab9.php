

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">List of Rooms</div>

    <div class="card-body">

        <a href="<?php echo e(route('app.admin.room.create')); ?>" class="btn btn-primary">Create Room</a>
        
        <table class="table">
            <tr>
                <th>No</th>
                <th>Room Name</th>
                <th>Capacity</th>
                <th>Facility</th>
                <th>Photo</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php ($i = 0); ?>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($room->name); ?></td>
                <td><?php echo e($room->capacity); ?></td>
                <td><?php echo e($room->facility); ?></td>
                <td>
                    <?php if($room->photo): ?>
                    <img src="<?php echo e(asset('uploads/rooms/'.$room->photo)); ?>" style="width:100px;">
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($room->status == 1): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Inactive</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('app.admin.room.destroy', $room->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                    <a href="<?php echo e(route('app.admin.room.edit', $room->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/admin/room_index.blade.php ENDPATH**/ ?>