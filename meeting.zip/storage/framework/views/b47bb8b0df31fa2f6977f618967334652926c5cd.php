

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">Booking Details</div>

    <div class="card-body">

        <?php if($booking->id): ?> 
            <form action="<?php echo e(route('app.booking.update', $booking->id)); ?>" method="post">
            <input type="hidden" name="_method" value="PUT">
        <?php else: ?>
            <form action="<?php echo e(route('app.booking.store')); ?>" method="post">
            <input type="hidden" name="_method" value="POST">
        <?php endif; ?>

        <?php echo csrf_field(); ?>
        <table class="table">
            <tr>
                <th>Room Name</th>
                <td>
                    <select class="form-control" name="room_id">
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Date</th>
                <td>
                    <input type="date" class="form-control" name="date" value="<?php echo e(old('date', $booking->date)); ?>">
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Time From</th>
                <td>
                    <input type="time" class="form-control" name="time_from" value="<?php echo e(old('time_from', $booking->time_from)); ?>">
                    <?php $__errorArgs = ['time_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Time To</th>
                <td>
                    <input type="time" class="form-control" name="time_to" value="<?php echo e(old('time_to', $booking->time_to)); ?>">
                    <?php $__errorArgs = ['time_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Pax</th>
                <td>
                    <input type="text" class="form-control" name="pax" value="<?php echo e(old('pax', $booking->pax)); ?>">
                    <?php $__errorArgs = ['pax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Remark</th>
                <td>
                    <input type="text" class="form-control" name="remark" value="<?php echo e(old('remark', $booking->remark)); ?>">
                    <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
        </table>

        <a href="<?php echo e(route('app.booking.index')); ?>" class="btn btn-info">Cancel</a>
        <button type="submit" class="btn btn-primary">Save</button>

        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/user/booking_form.blade.php ENDPATH**/ ?>