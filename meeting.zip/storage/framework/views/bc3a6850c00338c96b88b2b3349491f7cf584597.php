

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">Room Details</div>

    <div class="card-body">

        <?php if($room->id): ?> 
            <form action="<?php echo e(route('app.admin.room.update', $room->id)); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">
        <?php else: ?>
            <form action="<?php echo e(route('app.admin.room.store')); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="POST">
        <?php endif; ?>

        <?php echo csrf_field(); ?>
        <table class="table">
            <tr>
                <th>Room Name</th>
                <td>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $room->name)); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Capacity</th>
                <td>
                    <input type="text" class="form-control" name="capacity" value="<?php echo e(old('capacity', $room->capacity)); ?>">
                    <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Facility</th>
                <td>
                    <?php 
                    $facilities = $room->facility ? json_decode($room->facility) : [];
                    ?>
                    <table>
                        <tr>
                            <td><input type="checkbox" name="facility[]" value="Projektor" <?php if(in_array('Projektor', $facilities)): ?> checked <?php endif; ?>></td>
                            <td>Projektor</td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facility[]" value="TV" <?php if(in_array('TV', $facilities)): ?> checked <?php endif; ?>></td>
                            <td>TV</td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facility[]" value="Whiteboard" <?php if(in_array('Whiteboard', $facilities)): ?> checked <?php endif; ?>></td>
                            <td>Whiteboard</td>
                        </tr>
                    </table>
                    <?php $__errorArgs = ['facility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Photo</th>
                <td>
                    <input type="file" class="form-control" name="photo">
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <th>Status</th>
                <td>
                    <select class="form-control" name="status">
                        <option value="1" <?php if(old('status', $room->status) == '1'): ?> selected <?php endif; ?>>Active</option>
                        <option value="0" <?php if(old('status', $room->status) == '0'): ?> selected <?php endif; ?>>Inactive</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
        </table>

        <a href="<?php echo e(route('app.admin.room.index')); ?>" class="btn btn-info">Cancel</a>
        <button type="submit" class="btn btn-primary">Save</button>

        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/admin/room_form.blade.php ENDPATH**/ ?>