

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">List of My Bookings</div>

    <div class="card-body">

        <a href="<?php echo e(route('app.booking.create')); ?>" class="btn btn-primary">Create New Booking</a>
        
        <table class="table">
            <tr>
                <th>No</th>
                <th>Date</th>
                <th>Room Name</th>
                <th>Time From</th>
                <th>Time To</th>
                <th>Pax</th>
                <th>Remark</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php ($i = 0); ?>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($booking->date); ?></td>
                <td><?php echo e($booking->room->name); ?></td>
                <td><?php echo e($booking->time_from); ?></td>
                <td><?php echo e($booking->time_to); ?></td>
                <td><?php echo e($booking->pax); ?></td>
                <td><?php echo e($booking->remark); ?></td>
                <td>
                    <?php if($booking->status == 0): ?>
                        <span class="badge bg-warning">Pending</span>
                    <?php elseif($booking->status == 1): ?>
                        <span class="badge bg-success">Success</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Rejected</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($booking->status == 0): ?>
                    <form action="<?php echo e(route('app.booking.destroy', $booking->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                    <a href="<?php echo e(route('app.booking.edit', $booking->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.system_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\meeting\resources\views/user/booking_index.blade.php ENDPATH**/ ?>